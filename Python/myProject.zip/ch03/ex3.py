#ex3.py

#대소문자 구분
#자바와 선언 문법 같음

boolVar = False
intVar = 100
floatVar = 123.45
strVar1 = "반갑다 기주야~"
strVar2 = "반갑다 영문아~"
print(strVar2)
strVar2 = True
print(type(intVar))
print(type(strVar2))