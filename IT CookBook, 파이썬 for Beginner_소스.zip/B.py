from Module1 import func1, func2, func3 # 또는 from Module1 import  *

## 메인 코드 부분
func1()
func2()
func3()
