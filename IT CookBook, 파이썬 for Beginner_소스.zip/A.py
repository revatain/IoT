import Module1

## 메인 코드 부분
Module1.func1()
Module1.func2()
Module1.func3()

