for i in range(0, 3, 1) :
     print("안녕하세요? for 문을 공부 중입니다. ^^")

