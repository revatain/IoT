a = int(input("정수를 입력하세요 : "))

if a % 2 == 0 :
    print("짝수를 입력했군요.")
else :
    print("홀수를 입력했군요.")
