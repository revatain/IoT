i, hap = 0, 0

for i in range(501, 1001, 2) :
     hap = hap + i
	
print("500과 1000 사이에 있는 홀수의 합계 : %d" % hap)
