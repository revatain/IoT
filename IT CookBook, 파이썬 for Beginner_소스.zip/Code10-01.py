from tkinter import *

window = Tk()

## 이 부분에서 화면을 구성하고 처리 ## 

window.mainloop()
