a = 200

if a < 100 :
    print("100보다 작군요.")
else :
    print("100보다 크군요.")
