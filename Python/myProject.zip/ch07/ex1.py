# ex1.py

aa = [0, 0, 0, 0]
sum = 0

aa[0] = int(input("1번째 숫자 : "))
aa[1] = int(input("2번째 숫자 : "))
aa[2] = int(input("3번째 숫자 : "))
aa[3] = int(input("4번째 숫자 : "))

sum = aa[0] + aa[1] + aa[2] + aa[3]
print("합계 ==> %d" % sum)
