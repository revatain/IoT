#ex3.py

import turtle #필요한 모듈을 가져옴

turtle.shape('turtle')

turtle.color('red')
turtle.begin_fill()
turtle.circle(50)
turtle.end_fill()
turtle.done()